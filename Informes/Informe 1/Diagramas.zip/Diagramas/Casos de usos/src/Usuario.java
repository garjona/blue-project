import Ticket;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("88451ee3-a805-4247-abae-6e3626003e8e")
public class Usuario {
    @objid ("b1635b5f-8c0d-4451-ab00-78e127c752b8")
    public Ticket ticket;

}
