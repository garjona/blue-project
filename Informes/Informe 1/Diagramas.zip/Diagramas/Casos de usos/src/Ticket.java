import Ticket;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("92781701-2c30-463b-a2d1-34317d1e2276")
public class Ticket {
    @objid ("dd291bd6-d996-41e1-8d9f-17a1c5eca134")
    public Ticket ticket;

}
