import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("6cefab5e-b195-4328-a436-7fcfaabcb715")
public class Class {
}
